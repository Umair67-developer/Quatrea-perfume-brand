window.QUATREA = {
  order: ['spring', 'summer', 'autumn', 'winter'],
  s: {
    spring: {
      key: 'spring', n: 'I', season: 'Printemps', en: 'Spring', name: 'Rosée', family: 'Floral Fresh', conc: 18, hours: '6–7',
      window: '20 Mar — 20 Jun', marker: 79, markerLabel: 'Equinox · 20.03', fx: 'petals',
      bg: '#E9ECDF', ink: '#1E2B23', accent: '#D9848C', soft: '#D3DECA', deep: '#5F7E5E', liquid: ['#F7DCD8', '#E7A1A9'], label: '#FBF9F3',
      line: 'Rain on the orchard, and every peony opening on the same morning.',
      lede: 'A wet, green floral. Pear blossom and rain over peony, settling into soft orris and clean musk.',
      chapterBg: ['#DDE3D6', '#CFDACB', '#F0DEDC'],
      chapters: [
        { t: '05:42', d: '20 March · the equinox', p: 'Light arrives before the warmth does. The grass is still cold enough to hold the dew.' },
        { t: '08:10', d: 'An April shower', p: 'Rain moves through the orchard. Pear blossom bruises under every footstep.' },
        { t: '12:04', d: 'Late May, noon', p: 'The peonies open all at once, as if they had agreed on it overnight.' }
      ],
      notes: {
        top: [
          { n: 'Pear blossom', o: 'Accord', d: 'Juicy and green at once; the smell of white petals on a branch still wet from rain.' },
          { n: 'Green mandarin', o: 'Sicily', d: 'Picked unripe, so it reads bright and slightly bitter rather than sweet.' },
          { n: 'Rain accord', o: 'Accord', d: 'Mineral, cool, faintly metallic. Petrichor on warm stone.' }
        ],
        heart: [
          { n: 'Peony', o: 'Accord', d: 'Rosy and watery, with a fresh, almost citrus edge.' },
          { n: 'Muguet', o: 'Accord', d: 'Lily of the valley, the May flower of France; crisp, white, green-stemmed.' },
          { n: 'Sakura', o: 'Accord', d: 'Cherry blossom, barely sweet, with a hint of almond.' }
        ],
        base: [
          { n: 'Orris butter', o: 'Florence', d: 'From iris rhizomes dried for three years; powdery, cool, like suede.' },
          { n: 'White musk', o: 'Molecular', d: 'Clean-skin warmth that stays close and lasts the afternoon.' },
          { n: 'Cedarwood', o: 'Virginia', d: 'Pencil shavings and dry wood, giving the flowers somewhere to stand.' }
        ]
      },
      quote: 'Wear it the way <em>April</em> wears rain: lightly, and more than once.',
      ritual: [
        { h: 'Morning', p: 'Two sprays on the inner wrists before you leave. It opens bright and settles within the hour.' },
        { h: 'Midday', p: 'One spray on a scarf or collar. Fabric holds the pear blossom longer than skin.' },
        { h: 'Pair with', p: 'Linen, light rain, open windows. Rosée layers well over N°II for early summer.' }
      ],
      price: { 30: 115, 50: 160, 100: 230 }
    },
    summer: {
      key: 'summer', n: 'II', season: 'Été', en: 'Summer', name: 'Solstice', family: 'Citrus Aromatic', conc: 20, hours: '7–8',
      window: '21 Jun — 21 Sep', marker: 172, markerLabel: 'Solstice · 21.06', fx: 'motes',
      bg: '#F3CF6E', ink: '#2A170B', accent: '#D9472A', soft: '#F7E2A4', deep: '#1D4E5E', liquid: ['#FBE6A2', '#F09A3C'], label: '#FFF8E6',
      line: 'The longest day: salt drying on your shoulders, neroli on warm skin.',
      lede: 'A sunlit citrus. Calabrian bergamot and sea salt over neroli and fig milk, drying down to driftwood and tonka.',
      chapterBg: ['#F6DA8A', '#F2BE58', '#EE9E52'],
      chapters: [
        { t: '05:01', d: '21 June · the solstice', p: 'The longest day of the year starts early and in no hurry at all.' },
        { t: '13:30', d: 'High July', p: 'Salt dries on your shoulders. Someone has left bergamot peel on the café table.' },
        { t: '21:47', d: 'August, very late', p: 'Sunset takes an hour. Neroli on warm skin, a fig tree still giving off heat.' }
      ],
      notes: {
        top: [
          { n: 'Bergamot', o: 'Calabria', d: 'The classic cologne citrus: bright, bitter-sweet, faintly floral.' },
          { n: 'Pink pepper', o: 'Réunion', d: 'A rosy sparkle rather than heat; it makes the citrus fizz.' },
          { n: 'Sea salt', o: 'Accord', d: 'Dry skin after a swim; ozone, mineral, sun.' }
        ],
        heart: [
          { n: 'Neroli', o: 'Tunisia', d: 'Steam-distilled bitter orange blossom; honeyed, green and luminous.' },
          { n: 'Fig milk', o: 'Accord', d: 'The sap from a snapped fig leaf, creamy and green.' },
          { n: 'Orange blossom', o: 'Morocco', d: 'Warmer and sweeter than neroli, the same tree, a different process.' }
        ],
        base: [
          { n: 'Ambrette seed', o: 'Ecuador', d: 'A plant musk with a pear-skin softness.' },
          { n: 'Driftwood', o: 'Accord', d: 'Sun-bleached wood, salt in the grain.' },
          { n: 'Tonka', o: 'Venezuela', d: 'Almond, hay and a little vanilla; the warmth of late afternoon.' }
        ]
      },
      quote: 'Spray it on, go outside, and let the <em>sun</em> do the rest.',
      ritual: [
        { h: 'Before the beach', p: 'Behind the knees and at the collarbone. Heat lifts citrus quickly, so go generous.' },
        { h: 'After dark', p: 'Re-apply to the hair at dusk. The neroli comes forward as the air cools.' },
        { h: 'Pair with', p: 'Cotton, cold rosé, a terrace. Layer with N°III as September arrives.' }
      ],
      price: { 30: 115, 50: 160, 100: 230 }
    },
    autumn: {
      key: 'autumn', n: 'III', season: 'Automne', en: 'Autumn', name: 'Feuille', family: 'Woody Amber', conc: 22, hours: '9–10',
      window: '22 Sep — 20 Dec', marker: 265, markerLabel: 'Equinox · 22.09', fx: 'leaves',
      bg: '#2E1812', ink: '#F2E2CC', accent: '#E08A3A', soft: '#4A261B', deep: '#7A2E1F', liquid: ['#E9A458', '#8E3418'], label: '#F5EBDC',
      line: 'Leaves burning at the orchard edge, plums splitting on warm stone.',
      lede: 'A smoky, fruited amber. Plum and saffron over fig leaf and tobacco, resting on labdanum and Haitian vetiver.',
      chapterBg: ['#3A2015', '#4C2414', '#24120E'],
      chapters: [
        { t: '16:20', d: '22 September · the equinox', p: 'Day and night share the clock again, and the light turns the colour of tea.' },
        { t: '17:05', d: 'October', p: 'Leaves smoulder at the orchard edge. Plums split open on the warm stone wall.' },
        { t: '19:40', d: 'November, first lamp', p: 'Black tea, a tobacco tin, a wool coat drying by the door.' }
      ],
      notes: {
        top: [
          { n: 'Smoked plum', o: 'Accord', d: 'Dark, jammy fruit with a curl of woodsmoke.' },
          { n: 'Saffron', o: 'Kashmir', d: 'Leathery, honeyed and metallic; a little goes a long way.' },
          { n: 'Cardamom', o: 'Guatemala', d: 'Green, cool spice that keeps the fruit from getting heavy.' }
        ],
        heart: [
          { n: 'Fig leaf', o: 'Accord', d: 'Green and coconut-milky, the last of summer turning.' },
          { n: 'Tobacco', o: 'Absolute', d: 'Cured leaf: hay, honey and dried fruit, not ashtray.' },
          { n: 'Black tea', o: 'Assam', d: 'Malty and tannic, a brewed warmth.' }
        ],
        base: [
          { n: 'Labdanum', o: 'Andalusia', d: 'Resin from rockrose; the backbone of amber, ambery and leathery.' },
          { n: 'Vetiver', o: 'Haiti', d: 'Earthy, smoky, rooty; the smell of soil after the harvest.' },
          { n: 'Oud accord', o: 'Accord', d: 'Dark wood with a soft animalic shadow.' }
        ]
      },
      quote: 'Best worn with a <em>wool coat</em> and nowhere you have to be.',
      ritual: [
        { h: 'Evening', p: 'One spray at the base of the throat. It is dense; you will not need a second.' },
        { h: 'On wool', p: 'A mist over a scarf keeps the smoke and plum alive for days.' },
        { h: 'Pair with', p: 'Leather, black tea, early dark. Layer under N°IV as the frost comes.' }
      ],
      price: { 30: 125, 50: 175, 100: 250 }
    },
    winter: {
      key: 'winter', n: 'IV', season: 'Hiver', en: 'Winter', name: 'Givre', family: 'Woody Powdery', conc: 24, hours: '10–12',
      window: '21 Dec — 19 Mar', marker: 355, markerLabel: 'Solstice · 21.12', fx: 'snow',
      bg: '#0D1624', ink: '#E4EBF2', accent: '#A9C6E3', soft: '#1A2638', deep: '#5B6B85', liquid: ['#DCE8F4', '#6F8FB6'], label: '#EEF3F8',
      line: 'Frost on the iris beds, incense in a cold cathedral, birch smoke on wool.',
      lede: 'A cold, luminous woody. Frost aldehydes and juniper over iris and frankincense, drying to birch tar and cashmere musk.',
      chapterBg: ['#132036', '#1B2D4A', '#080E18'],
      chapters: [
        { t: '07:58', d: '21 December · the solstice', p: 'The shortest day, barely awake. Your breath is the only thing moving.' },
        { t: '12:00', d: 'January', p: 'Frost on the iris beds. Juniper in the cold, every edge sharpened.' },
        { t: '23:30', d: 'February, late', p: 'Incense still hanging in a cold cathedral. Birch smoke caught in wool.' }
      ],
      notes: {
        top: [
          { n: 'Frost accord', o: 'Aldehydes', d: 'The bright, soapy sparkle of cold air; clean and slightly metallic.' },
          { n: 'Juniper berry', o: 'Macedonia', d: 'Resinous and gin-crisp, with a pine edge.' },
          { n: 'Elemi', o: 'Philippines', d: 'A lemony resin, peppery and luminous.' }
        ],
        heart: [
          { n: 'Iris pallida', o: 'Florence', d: 'Cool, powdery, carrot-earthy; one of perfumery’s most precious materials.' },
          { n: 'Violet leaf', o: 'Egypt', d: 'Green, cucumber-crisp, a little like snow on leaves.' },
          { n: 'Frankincense', o: 'Oman', d: 'Silver, lemony church smoke.' }
        ],
        base: [
          { n: 'Birch tar', o: 'Finland', d: 'Smoked leather; a fire seen through a window.' },
          { n: 'Cashmere musk', o: 'Molecular', d: 'Soft, woolly, skin-warm.' },
          { n: 'Benzoin', o: 'Laos', d: 'A vanillic resin that keeps the cold from feeling unkind.' }
        ]
      },
      quote: 'Cold air carries scent further. <em>Wear less</em> than you think.',
      ritual: [
        { h: 'Before going out', p: 'One spray on the chest under your coat. Body heat releases it slowly all day.' },
        { h: 'At night', p: 'A single spray on the pillow. Iris and benzoin are made for long, dark evenings.' },
        { h: 'Pair with', p: 'Cashmere, snow light, candles. As March returns, the wheel turns back to N°I.' }
      ],
      price: { 30: 135, 50: 185, 100: 265 }
    }
  }
};
