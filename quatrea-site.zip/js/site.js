(function () {
  'use strict';
  const D = window.QUATREA, S = D.s, ORDER = D.order;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const RM = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const FINE = matchMedia('(pointer: fine)').matches;
  const body = document.body;
  const PAGE = body.dataset.page;
  let FROM_NAV = false; try { FROM_NAV = sessionStorage.getItem('q_nav') === '1'; } catch (e) {}
  document.documentElement.classList.add('js');

  const store = {
    get(k, d) { try { const v = localStorage.getItem('q_' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('q_' + k, JSON.stringify(v)); } catch (e) {} }
  };
  const hex = h => { h = h.replace('#', ''); return [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)); };
  const mix = (a, b, t) => { const A = hex(a), B = hex(b); return `rgb(${A.map((v, i) => Math.round(lerp(v, B[i], t))).join(',')})`; };
  const ARROW = '<svg class="arrow" viewBox="0 0 22 10" fill="none" stroke="currentColor" stroke-width="1.2"><path d="M0 5h21M16 .5 21 5l-5 4.5"/></svg>';

  /* ---------------- Logo (quatrefoil, one lobe per season) ---------------- */
  const LOBES = ['M-8,-8 A8,8 0 0 1 8,-8 L0,0Z', 'M8,-8 A8,8 0 0 1 8,8 L0,0Z', 'M8,8 A8,8 0 0 1 -8,8 L0,0Z', 'M-8,8 A8,8 0 0 1 -8,-8 L0,0Z'];
  const mark = (mono) => `<svg viewBox="-17 -17 34 34" aria-hidden="true">${LOBES.map((d, i) => `<path d="${d}" fill="${mono ? 'currentColor' : S[ORDER[i]].accent}" ${mono ? `opacity="${[1, .75, .5, .3][i]}"` : ''}/>`).join('')}</svg>`;
  const QUATRE = 'M-8,-8 A8,8 0 0 1 8,-8 A8,8 0 0 1 8,8 A8,8 0 0 1 -8,8 A8,8 0 0 1 -8,-8Z';

  /* ---------------- Bottle ---------------- */
  let uid = 0;
  function bottle(key, o = {}) {
    const s = S[key], id = 'b' + (uid++), lvl = o.level ?? 0;
    let wave = 'M-200,0';
    for (let i = 0; i < 12; i++) wave += ' q25,-7 50,0 t50,0';
    wave += ' V240 H-200Z';
    return `<svg class="bottle" viewBox="0 0 200 330" aria-hidden="true">
<defs>
<linearGradient id="${id}g" x1="0" x2="1"><stop offset="0" stop-color="#fff" stop-opacity=".6"/><stop offset=".14" stop-color="#fff" stop-opacity=".08"/><stop offset=".7" stop-color="#fff" stop-opacity=".02"/><stop offset=".92" stop-color="#fff" stop-opacity=".3"/><stop offset="1" stop-color="#fff" stop-opacity=".05"/></linearGradient>
<linearGradient id="${id}l" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${s.liquid[0]}"/><stop offset="1" stop-color="${s.liquid[1]}"/></linearGradient>
<linearGradient id="${id}m" x1="0" x2="1"><stop offset="0" stop-color="#6b5124"/><stop offset=".22" stop-color="#e8d197"/><stop offset=".45" stop-color="#a98140"/><stop offset=".7" stop-color="#f6e6b8"/><stop offset="1" stop-color="#6b5124"/></linearGradient>
<radialGradient id="${id}r" cx=".5" cy=".3" r=".8"><stop offset="0" stop-color="#fff" stop-opacity=".25"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>
<clipPath id="${id}c"><rect x="29" y="84" width="142" height="212" rx="9"/></clipPath>
</defs>
<ellipse cx="100" cy="318" rx="80" ry="7" fill="#000" opacity=".2"/>
<g class="b-body">
<rect x="18" y="72" width="164" height="236" rx="16" fill="${s.liquid[0]}" fill-opacity=".22"/>
<g clip-path="url(#${id}c)"><g class="b-liquid" style="transform:translateY(${110 + lvl}px)">
<g class="b-wave2" opacity=".55"><path d="${wave}" fill="${s.liquid[1]}" transform="translate(0,-6)"/></g>
<g class="b-wave"><path d="${wave}" fill="url(#${id}l)"/></g></g></g>
<rect x="18" y="72" width="164" height="236" rx="16" fill="url(#${id}g)" stroke="#fff" stroke-opacity=".7" stroke-width="1.2"/>
<rect x="18" y="72" width="164" height="236" rx="16" fill="url(#${id}r)"/>
<rect x="25" y="82" width="7" height="214" rx="3.5" fill="#fff" opacity=".45"/>
<rect x="164" y="90" width="3" height="190" rx="1.5" fill="#fff" opacity=".35"/>
<rect x="24" y="290" width="152" height="12" rx="6" fill="#fff" opacity=".18"/>
</g>
<g class="b-label">
<rect x="54" y="176" width="92" height="78" fill="${s.label}" opacity=".96"/>
<rect x="58" y="180" width="84" height="70" fill="none" stroke="${s.deep}" stroke-opacity=".5" stroke-width=".6"/>
<text x="100" y="196" text-anchor="middle" font-family="Jost, sans-serif" font-size="6.5" letter-spacing="3" fill="#222" font-weight="500">QUATRÉA</text>
<text x="100" y="224" text-anchor="middle" font-family="Bodoni Moda, Didot, serif" font-style="italic" font-size="19" fill="#151515">${s.name}</text>
<text x="100" y="240" text-anchor="middle" font-family="Jost, sans-serif" font-size="5" letter-spacing="2" fill="#444">N°${s.n} · ${s.season.toUpperCase()}</text>
</g>
<g class="b-neck"><rect x="84" y="58" width="32" height="16" fill="url(#${id}m)"/><rect x="80" y="70" width="40" height="4" rx="1" fill="url(#${id}m)"/></g>
<g class="b-cap"><rect x="64" y="4" width="72" height="56" rx="3" fill="url(#${id}m)"/>
<rect x="64" y="4" width="72" height="4" fill="#fff" opacity=".3"/>
<path d="${QUATRE}" transform="translate(100,32) scale(.95)" fill="none" stroke="#3b2b10" stroke-opacity=".55" stroke-width="1.1"/>
<path d="${LOBES[ORDER.indexOf(key)]}" transform="translate(100,32) scale(.95)" fill="#3b2b10" fill-opacity=".45"/></g>
</svg>`;
  }

  /* ---------------- Generative note glyph ---------------- */
  function glyph(name, s, i) {
    let h = 0; for (const c of name) h = (h * 31 + c.charCodeAt(0)) >>> 0;
    const petals = 5 + (h % 6), rr = 30 + (h % 25), ry = 10 + (h >>> 4) % 14, rot = h % 90;
    let p = '';
    for (let k = 0; k < petals; k++) p += `<ellipse cx="100" cy="${100 - rr}" rx="${ry}" ry="${rr}" transform="rotate(${rot + k * 360 / petals} 100 100)"/>`;
    let dots = '';
    const nd = 12 + h % 24;
    for (let k = 0; k < nd; k++) { const a = k / nd * Math.PI * 2; dots += `<circle cx="${(100 + Math.cos(a) * 88).toFixed(1)}" cy="${(100 + Math.sin(a) * 88).toFixed(1)}" r="${k % 3 ? .9 : 1.8}"/>`; }
    return `<svg viewBox="0 0 200 200" aria-hidden="true">
<circle cx="100" cy="100" r="${62 + h % 20}" fill="${[s.accent, s.liquid[1], s.deep][i % 3]}" opacity=".22"/>
<g class="spin" fill="none" stroke="currentColor" stroke-width=".8" opacity=".85">${p}</g>
<g fill="currentColor" opacity=".55" class="spin">${dots}</g>
<circle cx="100" cy="100" r="${4 + h % 6}" fill="${s.accent}"/>
</svg>`;
  }

  /* ---------------- Particle atmospheres ---------------- */
  function fx(canvas, type, s, opts = {}) {
    const ctx = canvas.getContext('2d');
    let w = 0, h = 0, dpr = Math.min(2, devicePixelRatio || 1), visible = true, mx = -999, my = -999;
    const density = opts.density || 1;
    const count = Math.round(({ snow: 160, motes: 70, petals: 46, leaves: 34, blobs: 4 }[type]) * density * (RM ? .3 : 1));
    const P = [];
    const pal = { petals: ['#F2C4C6', '#E9A1A9', '#FBE3E1', '#F7D6D3'], leaves: ['#C8642B', '#E08A3A', '#9A3B1E', '#D9A441', '#7A2E1F'], snow: ['#FFFFFF'], motes: ['#FFF3C4', '#FFE08A', '#FFFFFF'] }[type] || [];
    function resize() {
      const r = canvas.getBoundingClientRect(); w = r.width; h = r.height;
      canvas.width = w * dpr; canvas.height = h * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    function spawn(p, init) {
      p.z = Math.random() * .8 + .2;
      p.x = Math.random() * w; p.y = init ? Math.random() * h : (type === 'motes' ? h + 20 : -30);
      p.r = (type === 'snow' ? 1 + p.z * 2.6 : type === 'motes' ? 1 + Math.random() * 2.4 : 6 + p.z * 9);
      p.vy = type === 'motes' ? -(.15 + Math.random() * .4) : (type === 'snow' ? .3 + p.z * 1.1 : .5 + p.z * .9);
      p.vx = (Math.random() - .5) * .4; p.rot = Math.random() * 6.28; p.vr = (Math.random() - .5) * .04;
      p.ph = Math.random() * 6.28; p.c = pal[(Math.random() * pal.length) | 0]; p.ox = 0; p.oy = 0;
      return p;
    }
    resize();
    if (type === 'blobs') {
      ORDER.forEach((k, i) => P.push({ c: S[k].accent, x: [.2, .8, .75, .25][i], y: [.3, .25, .8, .75][i], ph: i * 1.7 }));
    } else for (let i = 0; i < count; i++) P.push(spawn({}, true));
    new ResizeObserver(resize).observe(canvas);
    new IntersectionObserver(e => { visible = e[0].isIntersecting; }).observe(canvas);
    const host = opts.host || canvas.parentElement;
    host.addEventListener('pointermove', e => { const r = canvas.getBoundingClientRect(); mx = e.clientX - r.left; my = e.clientY - r.top; });
    host.addEventListener('pointerleave', () => { mx = my = -999; });
    let t = 0;
    function leaf(p) {
      const r = p.r; ctx.beginPath(); ctx.moveTo(0, -r); ctx.quadraticCurveTo(r * .95, -r * .2, 0, r); ctx.quadraticCurveTo(-r * .95, -r * .2, 0, -r); ctx.fill();
      ctx.strokeStyle = 'rgba(40,10,0,.35)'; ctx.lineWidth = .8; ctx.beginPath(); ctx.moveTo(0, -r); ctx.lineTo(0, r * 1.3); ctx.stroke();
    }
    function frame() {
      requestAnimationFrame(frame);
      if (!visible || !w) return;
      t += 1; ctx.clearRect(0, 0, w, h);
      if (type === 'blobs') {
        ctx.globalCompositeOperation = 'lighter';
        P.forEach((b, i) => {
          const x = (b.x + Math.sin(t * .003 + b.ph) * .08 + (mx > 0 ? (mx / w - .5) * .06 * (i % 2 ? 1 : -1) : 0)) * w;
          const y = (b.y + Math.cos(t * .0025 + b.ph) * .08) * h, R = Math.max(w, h) * .42;
          const g = ctx.createRadialGradient(x, y, 0, x, y, R);
          g.addColorStop(0, b.c + '66'); g.addColorStop(1, b.c + '00');
          ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
        });
        ctx.globalCompositeOperation = 'source-over';
        return;
      }
      if (type === 'motes') {
        const sx = w * .72 + Math.sin(t * .002) * 40, sy = h * .28;
        const g = ctx.createRadialGradient(sx, sy, 0, sx, sy, Math.min(w, h) * .55);
        g.addColorStop(0, 'rgba(255,248,214,.85)'); g.addColorStop(.25, 'rgba(255,214,120,.35)'); g.addColorStop(1, 'rgba(255,200,90,0)');
        ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
      }
      for (const p of P) {
        p.ph += .02;
        const dx = p.x - mx, dy = p.y - my, d2 = dx * dx + dy * dy;
        if (d2 < 14400) { const f = (1 - Math.sqrt(d2) / 120) * 2.2; p.ox += dx / 120 * f; p.oy += dy / 120 * f; }
        p.ox *= .94; p.oy *= .94;
        p.x += p.vx + Math.sin(p.ph) * (type === 'snow' ? .3 : .8) + p.ox * .1; p.y += p.vy + p.oy * .1;
        p.rot += p.vr;
        if (p.y > h + 40 || p.y < -60 || p.x < -60 || p.x > w + 60) spawn(p, false);
        ctx.save(); ctx.translate(p.x, p.y);
        if (type === 'snow') {
          ctx.globalAlpha = .35 + p.z * .6; ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(0, 0, p.r, 0, 6.28); ctx.fill();
        } else if (type === 'motes') {
          ctx.globalAlpha = .4 + .5 * Math.abs(Math.sin(p.ph * .7)); ctx.fillStyle = p.c; ctx.shadowColor = '#FFE08A'; ctx.shadowBlur = 8;
          ctx.beginPath(); ctx.arc(0, 0, p.r, 0, 6.28); ctx.fill();
        } else {
          ctx.rotate(p.rot); ctx.scale(Math.cos(p.ph * 1.3), 1); ctx.globalAlpha = .55 + p.z * .45; ctx.fillStyle = p.c;
          if (type === 'leaves') leaf(p);
          else { ctx.beginPath(); ctx.ellipse(0, 0, p.r * .62, p.r * .4, 0, 0, 6.28); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,.35)'; ctx.beginPath(); ctx.ellipse(-p.r * .15, -p.r * .08, p.r * .25, p.r * .12, 0, 0, 6.28); ctx.fill(); }
        }
        ctx.restore();
      }
    }
    frame();
  }

  /* ---------------- Shared chrome ---------------- */
  function chrome() {
    const cur = PAGE === 'season' ? body.dataset.season : PAGE;
    const hdr = document.createElement('header');
    hdr.className = 'hdr';
    hdr.innerHTML = `<a class="logo" href="index.html" aria-label="Quatréa home">${mark(true)}<span class="logo__word">Quatréa</span></a>
<nav class="nav" aria-label="Main">
<div class="nav__seasons">${ORDER.map(k => `<a href="${k}.html" ${cur === k ? 'aria-current="page"' : ''}><i></i>${S[k].en}</a>`).join('')}</div>
<a class="hide-sm" href="atelier.html" ${cur === 'atelier' ? 'aria-current="page"' : ''}>Atelier</a>
<a class="hide-sm" href="finder.html" ${cur === 'finder' ? 'aria-current="page"' : ''}>Finder</a>
<button class="bag-btn" type="button" data-open-bag>Bag<span class="num" data-bag-count>0</span></button>
<button class="menu-btn" type="button" aria-expanded="false" data-menu>Menu</button>
</nav>`;
    body.prepend(hdr);
    const menu = document.createElement('div');
    menu.className = 'menu'; menu.id = 'menu';
    menu.innerHTML = `<button class="menu__close label" type="button" data-menu-close>Close</button>
${ORDER.map(k => `<a href="${k}.html"><small>N°${S[k].n}</small>${S[k].en}</a>`).join('')}
<a href="atelier.html"><small>—</small>Atelier</a><a href="finder.html"><small>—</small>Finder</a>`;
    body.append(menu);
    $('[data-menu]').addEventListener('click', e => { menu.classList.add('is-open'); e.currentTarget.setAttribute('aria-expanded', 'true'); });
    $('[data-menu-close]').addEventListener('click', () => { menu.classList.remove('is-open'); $('[data-menu]').setAttribute('aria-expanded', 'false'); });

    // curtain
    const c = document.createElement('div');
    c.className = 'curtain'; c.innerHTML = '<span></span><span></span><span></span><span></span>';
    body.append(c);
    try { sessionStorage.removeItem('q_nav'); } catch (e) {}
    if (FROM_NAV && !RM) {
      c.classList.add('no-anim', 'is-cover', 'is-leaving');
      requestAnimationFrame(() => requestAnimationFrame(() => { c.classList.remove('no-anim'); c.classList.remove('is-cover'); }));
    }
    document.addEventListener('click', e => {
      const a = e.target.closest('a[href]');
      if (!a || e.metaKey || e.ctrlKey || e.shiftKey || a.target) return;
      const href = a.getAttribute('href');
      if (!/^[a-z]+\.html(#[\w-]+)?$/.test(href)) return;
      e.preventDefault();
      if (RM) { location.href = href; return; }
      c.classList.remove('is-leaving'); c.classList.add('is-cover');
      try { sessionStorage.setItem('q_nav', '1'); } catch (e2) {}
      setTimeout(() => { location.href = href; }, 820);
    });
    addEventListener('pageshow', e => { if (e.persisted) c.classList.remove('is-cover'); });

    // cursor
    if (FINE && !RM) {
      const k = document.createElement('div'); k.className = 'cursor'; k.innerHTML = '<span>View</span>'; body.append(k);
      let x = innerWidth / 2, y = innerHeight / 2, cx = x, cy = y;
      addEventListener('pointermove', e => { x = e.clientX; y = e.clientY; });
      (function loop() { cx = lerp(cx, x, .2); cy = lerp(cy, y, .2); k.style.transform = `translate(${cx}px,${cy}px)`; requestAnimationFrame(loop); })();
      document.addEventListener('pointerover', e => {
        const a = e.target.closest('a, button, label, [data-cursor]');
        k.classList.toggle('is-link', !!a);
        if (a) k.querySelector('span').textContent = a.dataset.cursor || (a.tagName === 'A' ? 'View' : '');
      });
    }

    // header hide on scroll down
    let lastY = 0;
    onScroll(y => { hdr.classList.toggle('is-hidden', y > lastY && y > 200); lastY = y; });

    // footer
    const f = $('footer[data-footer]');
    if (f) {
      f.className = 'ftr';
      f.innerHTML = `<div class="ftr__grid">
<div class="news"><span class="label">Letters from the atelier</span><p>Four letters a year, one on each equinox and solstice.</p>
<form novalidate><label class="sr" for="nl-email">Email address</label><input id="nl-email" type="email" placeholder="Your email" autocomplete="email" required><button type="submit" aria-label="Subscribe">${ARROW}</button></form><div class="msg" aria-live="polite"></div></div>
<div><h4 class="label">The collection</h4><ul>${ORDER.map(k => `<li><a href="${k}.html">N°${S[k].n} ${S[k].name}</a></li>`).join('')}</ul></div>
<div><h4 class="label">The house</h4><ul><li><a href="atelier.html">Atelier</a></li><li><a href="finder.html">Fragrance finder</a></li><li><a href="index.html">The wheel of the year</a></li></ul></div>
<div><h4 class="label">Calendar</h4><ul class="num"><li>20.03 Spring equinox</li><li>21.06 Summer solstice</li><li>22.09 Autumn equinox</li><li>21.12 Winter solstice</li></ul></div>
</div>
<div class="ftr__word" aria-hidden="true">Quatréa</div>
<div class="ftr__base"><span>Quatréa is a fictional maison, a design concept.</span><span>Eaux de parfum, composed in four parts.</span></div>`;
      $('form', f).addEventListener('submit', e => {
        e.preventDefault(); const i = $('input', f), m = $('.msg', f);
        m.textContent = /\S+@\S+\.\S+/.test(i.value) ? 'Thank you. The next letter arrives on the coming equinox or solstice.' : 'Please enter a full email address, like name@example.com.';
        if (/\S+@\S+\.\S+/.test(i.value)) i.value = '';
      });
    }
    bag();
  }

  /* ---------------- Bag ---------------- */
  let bagItems = store.get('bag', []);
  function bag() {
    const dr = document.createElement('aside');
    dr.className = 'drawer'; dr.setAttribute('aria-label', 'Your bag');
    dr.innerHTML = `<div class="drawer__head"><h2>Your bag</h2><button type="button" class="label" data-close-bag>Close</button></div><ul class="drawer__list"></ul>
<div class="drawer__foot"><div class="row"><span>Total</span><span class="num" data-total>€0</span></div><button class="btn btn--solid" type="button" data-checkout>Checkout</button><small class="buy__small">This is a concept site; no order will be placed.</small></div>`;
    const scrim = document.createElement('div'); scrim.className = 'scrim';
    const toast = document.createElement('div'); toast.className = 'toast'; toast.setAttribute('role', 'status');
    body.append(scrim, dr, toast);
    const open = () => { dr.classList.add('is-open'); scrim.classList.add('on'); };
    const close = () => { dr.classList.remove('is-open'); scrim.classList.remove('on'); };
    $$('[data-open-bag]').forEach(b => b.addEventListener('click', open));
    $('[data-close-bag]', dr).addEventListener('click', close); scrim.addEventListener('click', close);
    addEventListener('keydown', e => { if (e.key === 'Escape') { close(); $('#menu')?.classList.remove('is-open'); } });
    $('[data-checkout]', dr).addEventListener('click', () => { say('Concept site: checkout is not connected.'); });
    let tt;
    function say(m) { toast.textContent = m; toast.classList.add('on'); clearTimeout(tt); tt = setTimeout(() => toast.classList.remove('on'), 2600); }
    function render() {
      const list = $('.drawer__list', dr);
      list.innerHTML = bagItems.length ? bagItems.map((it, i) => `<li><div>${bottle(it.k)}</div><div><div class="t">N°${S[it.k].n} ${S[it.k].name}</div><small>${it.ml} ml · Eau de Parfum</small></div><div style="text-align:right"><div class="num">€${S[it.k].price[it.ml]}</div><button type="button" data-rm="${i}">Remove</button></div></li>`).join('') : '<li class="drawer__empty" style="display:block;border:0">Your bag is empty. Each season has its own page; start with the one you are in.</li>';
      $('[data-total]', dr).textContent = '€' + bagItems.reduce((a, it) => a + S[it.k].price[it.ml], 0);
      $$('[data-bag-count]').forEach(n => n.textContent = bagItems.length);
      $$('[data-rm]', list).forEach(b => b.addEventListener('click', () => { bagItems.splice(+b.dataset.rm, 1); store.set('bag', bagItems); render(); }));
    }
    render();
    window.qAdd = (k, ml) => { bagItems.push({ k, ml }); store.set('bag', bagItems); render(); say(`N°${S[k].n} ${S[k].name}, ${ml} ml, added to your bag.`); };
  }

  /* ---------------- Scroll engine ---------------- */
  const scrollFns = [], scrollies = [];
  let lenis = null, vel = 0, sy = scrollY;
  function onScroll(fn) { scrollFns.push(fn); }
  function scrolly(el, fn) { scrollies.push({ el, fn }); }
  function initScroll() {
    if (!RM && window.Lenis) {
      lenis = new Lenis({ lerp: .085, smoothWheel: true, wheelMultiplier: .9 });
      lenis.on('scroll', e => { vel = e.velocity || 0; });
      document.documentElement.classList.add('lenis');
    }
    function raf(time) {
      if (lenis) lenis.raf(time);
      const y = scrollY;
      if (!lenis) { vel = y - sy; }
      sy = y;
      scrollFns.forEach(f => f(y, vel));
      const vh = innerHeight;
      for (const s of scrollies) {
        const r = s.el.getBoundingClientRect();
        if (r.bottom < -vh || r.top > vh * 2) continue;
        s.fn(clamp(-r.top / Math.max(1, r.height - vh)), r);
      }
      requestAnimationFrame(raf);
    }
    requestAnimationFrame(raf);
  }

  /* ---------------- Split + reveal ---------------- */
  function split(el) {
    const words = el.innerHTML.split(/(<br\s*\/?>|\s+)/);
    let ci = 0;
    el.innerHTML = words.map(w => {
      if (/^<br/.test(w)) return w; if (/^\s+$/.test(w)) return ' '; if (!w) return '';
      const em = /^<em>(.*)<\/em>$/.exec(w);
      const txt = em ? em[1] : w.replace(/<[^>]+>/g, '');
      const chars = Array.from(txt).map(ch => `<span class="sp-c"><span style="transition-delay:${(ci++ * .028).toFixed(3)}s">${ch}</span></span>`).join('');
      return `<span class="sp-w">${em ? `<em>${chars}</em>` : chars}</span>`;
    }).join('');
    el.setAttribute('aria-label', el.textContent);
  }
  function reveals() {
    $$('[data-split]').forEach(split);
    const els = $$('[data-split], [data-reveal]');
    const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { rootMargin: '0px 0px -8% 0px' });
    els.forEach(el => io.observe(el));
  }

  /* ---------------- Loader (home, once per session) ---------------- */
  function loader(done) {
    let seen = false; try { seen = sessionStorage.getItem('q_seen') === '1'; sessionStorage.setItem('q_seen', '1'); } catch (e) {}
    if (seen || RM || FROM_NAV) { done(); return; }
    const l = document.createElement('div'); l.className = 'loader';
    l.innerHTML = `<div class="loader__inner"><svg viewBox="-17 -17 34 34" fill="none" stroke-width=".8">${LOBES.map((d, i) => `<path d="${d.replace(' L0,0Z', '')}" stroke="${S[ORDER[i]].accent}"/>`).join('')}</svg><div class="loader__count num">DAY <span>001</span> / 365</div></div>`;
    body.append(l);
    const sp = $('span', l), t0 = performance.now();
    (function tick(t) {
      const p = clamp((t - t0) / 1700); sp.textContent = String(Math.max(1, Math.round((1 - Math.pow(1 - p, 3)) * 365))).padStart(3, '0');
      if (p < 1) requestAnimationFrame(tick); else { l.classList.add('is-done'); done(); setTimeout(() => l.remove(), 1200); }
    })(t0);
  }

  /* ================= HOME ================= */
  function home() {
    const hero = $('.h-hero');
    hero.querySelector('.h-hero__bottles').innerHTML = ORDER.map(k => `<a class="hb" href="${k}.html" data-cursor="${S[k].en}" aria-label="N°${S[k].n} ${S[k].name}"><div>${bottle(k)}</div></a>`).join('');
    fx($('.fx', hero), 'blobs', null);

    // wheel
    const wheel = $('.wheel');
    const svgNS = 'http://www.w3.org/2000/svg';
    const months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    const mdays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    const starts = mdays.reduce((a, d, i) => (a.push(i ? a[i - 1] + mdays[i - 1] : 0), a), []);
    const ang = d => (d / 365) * Math.PI * 2 - Math.PI / 2;
    let g = '';
    for (let d = 0; d < 365; d++) {
      const a = ang(d), major = starts.includes(d), r1 = major ? 246 : (d % 7 === 0 ? 258 : 263), r2 = 272;
      g += `<line x1="${(Math.cos(a) * r1).toFixed(1)}" y1="${(Math.sin(a) * r1).toFixed(1)}" x2="${(Math.cos(a) * r2).toFixed(1)}" y2="${(Math.sin(a) * r2).toFixed(1)}" stroke="currentColor" stroke-width="${major ? 1.4 : .6}" opacity="${major ? .9 : .45}"/>`;
    }
    months.forEach((m, i) => {
      const d = starts[i] + mdays[i] / 2, deg = d / 365 * 360;
      g += `<text transform="rotate(${deg}) translate(0,-226)" text-anchor="middle">${m}</text>`;
    });
    ORDER.forEach((k, i) => {
      const s = S[k], next = S[ORDER[(i + 1) % 4]], d0 = s.marker, d1 = next.marker + (i === 3 ? 365 : 0);
      const a0 = ang(d0), a1 = ang(d1), R = 292;
      g += `<path d="M${Math.cos(a0) * R},${Math.sin(a0) * R} A${R},${R} 0 0 1 ${Math.cos(a1) * R},${Math.sin(a1) * R}" fill="none" stroke="${s.accent}" stroke-width="3" opacity=".9"/>`;
      const a = ang(d0);
      g += `<g class="mk"><circle cx="${Math.cos(a) * 292}" cy="${Math.sin(a) * 292}" r="7" fill="${s.accent}" stroke="currentColor" stroke-width="1"/><text transform="rotate(${d0 / 365 * 360}) translate(0,-310)" text-anchor="middle">${s.markerLabel.toUpperCase()}</text></g>`;
    });
    g += `<circle r="200" fill="none" stroke="currentColor" stroke-width=".5" opacity=".35" stroke-dasharray="2 6"/>`;
    $('.wheel__ring', wheel).innerHTML = `<svg viewBox="-340 -340 680 680"><g class="rot">${g}</g></svg>`;
    $('.wheel__bottles', wheel).innerHTML = ORDER.map(k => `<div>${bottle(k)}</div>`).join('');
    $('.wheel__panels', wheel).innerHTML = ORDER.map(k => {
      const s = S[k];
      return `<div class="wpanel"><span class="label">N°${s.n} · ${s.season} · ${s.window}</span><h2>${s.name}</h2><p>${s.lede}</p>
<div class="notes-inline">${[s.notes.top[0], s.notes.heart[0], s.notes.base[0]].map(n => `<span>${n.n}</span>`).join('')}</div>
<div><a class="btn" href="${k}.html">Enter ${s.en} ${ARROW}</a></div></div>`;
    }).join('');
    const rot = $('.rot', wheel), bots = $$('.wheel__bottles > div', wheel), pans = $$('.wpanel', wheel), prog = $$('.wheel__progress i', wheel);
    const st = $('.wheel__sticky', wheel), dayN = $('[data-day]', wheel), dayD = $('[data-date]', wheel);
    let cur = -1;
    scrolly(wheel, p => {
      const day = (S.spring.marker + p * 365 * .985) % 365;
      rot.setAttribute('transform', `rotate(${-(day / 365) * 360})`);
      const idx = Math.min(3, Math.floor(p * 4)), q = p * 4 - idx;
      const a = S[ORDER[idx]], b = S[ORDER[Math.min(3, idx + 1)]];
      const k = idx < 3 ? clamp((q - .78) / .22) : 0;
      st.style.setProperty('--wbg', mix(a.bg, b.bg, k));
      st.style.setProperty('--wink', mix(a.ink, b.ink, k > .5 ? 1 : 0));
      const di = Math.floor(day);
      dayN.textContent = String(di + 1).padStart(3, '0');
      let m = 0; while (m < 11 && starts[m + 1] <= di) m++;
      dayD.textContent = `${di - starts[m] + 1} ${['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'][m]}`;
      const on = q > .9 && idx < 3 ? idx + 1 : idx;
      if (on !== cur) {
        cur = on;
        bots.forEach((x, i) => x.classList.toggle('on', i === on));
        pans.forEach((x, i) => x.classList.toggle('on', i === on));
        prog.forEach((x, i) => x.classList.toggle('on', i <= on));
      }
    });

    // collection cards
    $('.cards').innerHTML = ORDER.map(k => {
      const s = S[k];
      return `<a class="card" href="${k}.html" data-cursor="Enter" style="--c-bg:${s.bg};--c-ink:${s.ink}">
<canvas class="fx"></canvas>
<div class="card__top label"><span>N°${s.n}</span><span>${s.season}</span></div>
<div class="card__bottle">${bottle(k)}</div>
<div class="card__meta"><h3>${s.name}</h3><p class="card__notes">${[...s.notes.top, ...s.notes.heart].slice(0, 4).map(n => n.n).join(' · ')}</p>
<div class="card__go label"><span>${s.family} · ${s.conc}%</span>${ARROW}</div></div></a>`;
    }).join('');
    $$('.card').forEach((c, i) => {
      fx($('.fx', c), S[ORDER[i]].fx, S[ORDER[i]], { density: .35 });
      if (!FINE || RM) return;
      c.addEventListener('pointermove', e => { const r = c.getBoundingClientRect(); const x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5; c.style.transform = `rotateY(${x * 8}deg) rotateX(${-y * 8}deg)`; });
      c.addEventListener('pointerleave', () => { c.style.transform = ''; });
    });
    marquee();
    // teaser art
    const ta = $('[data-teaser-atelier]');
    if (ta) ta.innerHTML = `<div style="position:absolute;right:-6%;bottom:-18%;width:52%;transform:rotate(-14deg)">${bottle('autumn')}</div>`;
    const tf = $('[data-teaser-finder]');
    if (tf) tf.innerHTML = `<div style="position:absolute;right:-12%;top:50%;width:64%;transform:translateY(-50%);color:var(--ink);opacity:.9">${mark(false)}</div>`;
  }

  function marquee() {
    const m = $('.marquee__track'); if (!m) return;
    const words = ['Spring', 'Summer', 'Autumn', 'Winter'];
    const one = words.map((w, i) => `<span>${w}<svg viewBox="-17 -17 34 34"><path d="${QUATRE}" fill="${S[ORDER[i]].accent}"/></svg></span>`).join('');
    m.innerHTML = one + one + one + one;
    let x = 0, dir = 1;
    onScroll((y, v) => {
      if (RM) return;
      if (v) dir = v > 0 ? 1 : -1;
      x -= (0.6 + Math.min(12, Math.abs(v) * .5)) * dir;
      const W = m.scrollWidth / 4; if (x < -W) x += W; if (x > 0) x -= W;
      m.style.transform = `translateX(${x}px)`;
    });
  }

  /* ================= SEASON ================= */
  function season() {
    const k = body.dataset.season, s = S[k], i = ORDER.indexOf(k), nk = ORDER[(i + 1) % 4], n = S[nk];
    const app = $('#app');
    const tierTxt = { top: 'The first ten minutes. Bright, volatile, gone by the time you reach the street.', heart: 'The next few hours. The character of the perfume, warming on skin.', base: 'What lingers into evening and onto the scarf you wear tomorrow.' };
    app.innerHTML = `
<section class="s-hero">
  <canvas class="fx"></canvas>
  <h1 class="s-hero__title" data-split>${s.name}</h1>
  <div class="s-hero__bottle"><div class="float">${bottle(k)}</div></div>
  <div class="s-hero__meta" data-reveal><span class="label">N°${s.n} · ${s.season}</span><span class="label" style="opacity:.6">Eau de Parfum · ${s.window}</span></div>
  <p class="s-hero__line" data-reveal>${s.line}</p>
  <div class="scroll-cue label"><span>Scroll</span><i></i></div>
</section>
<section class="story" aria-label="The story">
  <div class="story__sticky">
    <div class="story__sun"></div>
    <div class="story__bottle"><div>${bottle(k)}</div></div>
    <div class="story__chapters">${s.chapters.map(c => `<article class="chapter"><div class="chapter__time num">${c.t}</div><div class="chapter__date label"><i></i>${c.d}</div><p>${c.p}</p></article>`).join('')}</div>
    <div class="story__ticks">${s.chapters.map(c => `<span class="label"><b></b>${c.t}</span>`).join('')}</div>
  </div>
</section>
<section class="notes" aria-label="Olfactory notes">
  <div class="notes__sticky">
    <div class="notes__head"><h2 data-split>The pyramid</h2><div class="bar"><i></i></div></div>
    <div class="notes__track">${['top', 'heart', 'base'].map((t, ti) => `<div class="tier"><div class="tier__intro"><span class="label">${['I', 'II', 'III'][ti]} / III</span><div style="display:grid;gap:14px"><h3>${t === 'top' ? 'Top' : t === 'heart' ? 'Heart' : 'Base'}</h3><p>${tierTxt[t]}</p></div></div>
      ${s.notes[t].map((nt, ni) => `<article class="note"><div class="note__art">${glyph(nt.n, s, ni + ti)}</div><div style="display:grid;gap:10px;align-content:start"><h4>${nt.n}</h4><p>${nt.d}</p></div><div class="note__o label"><span>${t} note</span><span>${nt.o}</span></div></article>`).join('')}</div>`).join('')}</div>
  </div>
</section>
<section class="facts">
  <div class="fact" data-reveal><span class="label">Concentration</span><b class="num" data-count="${s.conc}">0<small>%</small></b><p>Perfume oil in the formula. Eau de parfum sits between 15 and 25 percent.</p></div>
  <div class="fact" data-reveal><span class="label">On skin</span><b class="num">${s.hours}<small>h</small></b><p>Typical wear on skin. On wool or cotton, considerably longer.</p></div>
  <div class="fact" data-reveal><span class="label">Family</span><b style="font-size:clamp(40px,3.6vw,60px)">${s.family}</b><p>Its place on the fragrance wheel, the perfumer's map of scent families.</p></div>
  <div class="fact" data-reveal><span class="label">Season</span><b style="font-size:clamp(40px,3.6vw,60px)" class="num">${s.window.replace(' — ', '<br>')}</b><p>From ${s.markerLabel.split(' · ')[0].toLowerCase()} to the next turn of the wheel.</p></div>
</section>
<section class="ritual">
  <canvas class="fx" style="opacity:.5"></canvas>
  <blockquote data-reveal>${s.quote}</blockquote>
  <div class="ritual__steps">${s.ritual.map((r, ri) => `<div data-reveal style="transition-delay:${ri * .1}s"><span class="label" style="opacity:.6">0${ri + 1}</span><h4>${r.h}</h4><p>${r.p}</p></div>`).join('')}</div>
</section>
<section class="buy" id="buy">
  <div class="buy__art"><canvas class="fx"></canvas><div class="bottle-wrap">${bottle(k)}</div></div>
  <form class="buy__form">
    <span class="label">N°${s.n} · Eau de Parfum</span>
    <h2>${s.name}</h2>
    <p style="max-width:42ch;opacity:.85">${s.lede}</p>
    <fieldset class="sizes"><legend class="label">Size</legend>${[30, 50, 100].map(ml => `<label><input type="radio" name="ml" id="ml-${ml}" value="${ml}" ${ml === 50 ? 'checked' : ''}><span><b class="num">${ml} ml</b><small class="num">€${s.price[ml]}</small></span></label>`).join('')}</fieldset>
    <div style="display:flex;gap:26px;align-items:center;flex-wrap:wrap"><div class="price num" data-price>€${s.price[50]}</div><button class="btn btn--solid" type="submit">Add to bag ${ARROW}</button></div>
    <p class="buy__small">Refillable brass cap and glass. Every bottle is numbered by hand.</p>
  </form>
</section>
<a class="next" href="${nk}.html" style="--n-bg:${n.bg};--n-ink:${n.ink};--n-accent:${n.accent}" data-cursor="${n.en}">
  <span class="next__fill"></span>
  <div class="next__lbl label"><span>Continue the year</span><span>N°${n.n} · ${n.season}</span></div>
  <div class="next__name">${n.name}${ARROW}</div>
</a>`;

    fx($('.s-hero .fx'), s.fx, s);
    fx($('.ritual .fx'), s.fx, s, { density: .4 });
    fx($('.buy .fx'), s.fx, s, { density: .4 });
    const hb = $('.s-hero__bottle');
    scrolly($('.s-hero'), (p, r) => {
      const y = clamp(-r.top / r.height, 0, 1);
      $('.s-hero__title').style.transform = `translateY(${y * 30}%) scale(${1 - y * .12})`;
      hb.style.transform = `translateY(${y * -20}%) rotate(${y * 8}deg)`;
    });

    // story
    const story = $('.story'), chs = $$('.chapter', story), ticks = $$('.story__ticks span', story), sb = $('.story__bottle > div', story), sticky = $('.story__sticky', story), sun = $('.story__sun', story);
    const liquid = $('.story__bottle .b-liquid', story);
    let on = -1;
    scrolly(story, p => {
      const f = p * 3, idx = Math.min(2, Math.floor(f)), t = f - idx;
      if (idx !== on) { on = idx; chs.forEach((c, i) => { c.classList.toggle('on', i === idx); c.classList.toggle('past', i < idx); }); ticks.forEach((x, i) => x.classList.toggle('on', i <= idx)); }
      ticks.forEach((x, i) => x.querySelector('b').style.setProperty('--p', clamp(f - i)));
      const a = s.chapterBg[idx], b = s.chapterBg[Math.min(2, idx + 1)];
      sticky.style.setProperty('--chbg', mix(a, b, idx < 2 ? clamp((t - .7) / .3) : 0));
      sb.style.transform = `rotateY(${Math.sin(p * Math.PI * 2) * 22}deg) rotateZ(${(p - .5) * 10}deg) translateY(${Math.sin(p * Math.PI * 3) * 14}px)`;
      sun.style.transform = `translate(${-50 + (p - .5) * 60}%, ${-50 - Math.sin(p * Math.PI) * 30}%) scale(${.7 + Math.sin(p * Math.PI) * .5})`;
      if (liquid) liquid.style.transform = `translateY(${110 + p * 70}px)`;
    });

    // notes horizontal
    const notes = $('.notes'), track = $('.notes__track', notes), bar = $('.notes__head .bar', notes);
    function sizeNotes() { notes.style.height = `calc(100vh + ${Math.max(0, track.scrollWidth - innerWidth)}px)`; }
    sizeNotes(); addEventListener('resize', sizeNotes);
    scrolly(notes, p => { track.style.transform = `translateX(${-p * Math.max(0, track.scrollWidth - innerWidth)}px)`; bar.style.setProperty('--p', p); });

    // counters
    $$('[data-count]').forEach(el => {
      const to = +el.dataset.count, sm = el.querySelector('small').outerHTML;
      const io = new IntersectionObserver(es => {
        if (!es[0].isIntersecting) return; io.disconnect();
        const t0 = performance.now();
        (function tick(t) { const q = clamp((t - t0) / 1400); el.innerHTML = Math.round(to * (1 - Math.pow(1 - q, 3))) + sm; if (q < 1) requestAnimationFrame(tick); })(t0);
      });
      io.observe(el);
    });

    // buy
    const form = $('.buy__form'), price = $('[data-price]'), bw = $('.buy .bottle-wrap');
    form.addEventListener('change', () => {
      const ml = +form.ml.value; price.textContent = '€' + s.price[ml];
      bw.style.transform = `scale(${{ 30: .78, 50: .9, 100: 1.05 }[ml]})`;
    });
    bw.style.transform = 'scale(.9)';
    form.addEventListener('submit', e => { e.preventDefault(); window.qAdd(k, +form.ml.value); });
  }

  /* ================= ATELIER ================= */
  function atelier() {
    fx($('.a-hero .fx'), 'blobs', null);
    const proc = $('.process'), track = $('.process__track', proc), bars = $$('.process__bar span', proc);
    scrolly(proc, p => {
      const n = 5, x = p * (n - 1);
      track.style.transform = `translateX(${-x * innerWidth}px)`;
      bars.forEach((b, i) => { b.classList.toggle('on', i <= Math.round(x)); b.querySelector('i').style.setProperty('--p', clamp(x - i + 1)); });
      $$('.step__n', proc).forEach((el, i) => { el.style.transform = `translateX(${(i - x) * 30}%)`; });
    });
    const an = $('.anatomy'), bw = $('.anatomy__bottle', an);
    bw.innerHTML = bottle('winter');
    const cap = $('.b-cap', bw), neck = $('.b-neck', bw), label = $('.b-label', bw), liq = $('.b-liquid', bw), parts = $$('.part', an);
    [cap, neck, label].forEach(g => g.style.transition = 'none');
    scrolly(an, p => {
      const e = Math.sin(clamp(p * 1.25) * Math.PI / 2);
      cap.style.transform = `translateY(${-e * 90}px) rotate(${-e * 8}deg)`;
      neck.style.transform = `translateY(${-e * 40}px)`;
      label.style.transform = `translateX(${e * 150}px) rotate(${e * 6}deg)`;
      liq.style.transform = `translateY(${110 + e * 60}px)`;
      const a = Math.min(3, Math.floor(p * 4));
      parts.forEach((x, i) => x.classList.toggle('on', i === a));
    });
  }

  /* ================= FINDER ================= */
  function finder() {
    const Qs = [
      { q: 'Pick an <em>hour</em> of the day.', o: ['Dawn|Cool, damp, still', 'High noon|Bright, hot, loud', 'Dusk|Golden, then grey', 'Midnight|Quiet and clear'] },
      { q: 'Choose a <em>texture</em>.', o: ['Wet petals|Soft and cold', 'Warm sand|Grains on skin', 'Wool & leather|Heavy, worn-in', 'Fresh snow|Squeak underfoot'] },
      { q: 'What are you <em>drinking</em>?', o: ['Green tea|Grassy, light', 'Iced citrus|Sharp and sweet', 'Black tea|Malty, smoky', 'Mulled wine|Spiced and dark'] },
      { q: 'Where would you <em>rather</em> be?', o: ['An orchard|After the rain', 'A coastline|Late afternoon', 'A library|With the lamps on', 'A cathedral|Candles and stone'] }
    ];
    const stage = $('.f-stage'), prog = $('.f-progress');
    prog.innerHTML = ORDER.map(k => `<i style="--c:${S[k].accent}"></i>`).join('');
    stage.innerHTML = Qs.map((q, qi) => `<div class="q ${qi === 0 ? 'on' : ''}" role="group" aria-label="Question ${qi + 1} of 4"><span class="label">Question ${qi + 1} / 4</span><h2>${q.q}</h2>
<div class="opts">${q.o.map((o, oi) => { const [a, b] = o.split('|'); return `<button type="button" class="opt" data-s="${oi}" style="--c:${S[ORDER[oi]].accent}"><span class="label" style="opacity:.6">${String.fromCharCode(65 + oi)}</span><span style="display:grid;gap:6px"><b>${a}</b><small>${b}</small></span></button>`; }).join('')}</div></div>`).join('');
    const score = [0, 0, 0, 0]; let step = 0;
    const qs = $$('.q', stage), ticks = $$('i', prog), res = $('.result');
    stage.addEventListener('click', e => {
      const b = e.target.closest('.opt'); if (!b) return;
      score[+b.dataset.s]++; ticks[step].classList.add('done');
      qs[step].classList.remove('on'); qs[step].classList.add('out');
      step++;
      if (step < Qs.length) { qs[step].classList.add('on'); qs[step].querySelector('.opt').focus({ preventScroll: true }); return; }
      const max = Math.max(...score), win = ORDER[score.lastIndexOf(max) === score.indexOf(max) ? score.indexOf(max) : +b.dataset.s];
      const s = S[win];
      res.style.setProperty('--r-bg', s.bg); res.style.setProperty('--r-ink', s.ink);
      res.style.setProperty('--x', e.clientX + 'px'); res.style.setProperty('--y', e.clientY + 'px');
      res.innerHTML = `<canvas class="fx"></canvas><div class="result__bottle">${bottle(win)}</div><div class="result__copy"><span class="label">Your season · N°${s.n} · ${s.season}</span><h2>${s.name}</h2><p>${s.lede}</p>
<div class="result__row"><a class="btn btn--solid" href="${win}.html" style="--ink:${s.ink};--bg:${s.bg};--accent:${s.accent}">Discover ${s.name} ${ARROW}</a><button class="btn" type="button" data-again>Start again</button></div></div>`;
      res.classList.add('on'); res.setAttribute('aria-hidden', 'false');
      fx($('.fx', res), s.fx, s);
      $('[data-again]', res).addEventListener('click', () => location.reload());
    });
  }

  /* ---------------- Boot ---------------- */
  chrome();
  ({ home, season, atelier, finder }[PAGE] || (() => {}))();
  initScroll();
  const go = () => reveals();
  if (PAGE === 'home') loader(go); else go();
  if (location.hash && lenis) setTimeout(() => lenis.scrollTo(location.hash), 300);
})();
